python3 run.py --configs=ns3.yaml --run_dimensions
python3 run.py --configs=ns3.yaml --run_facts
python3 run.py --configs=btw.yaml --run_dimensions
python3 run.py --configs=btw.yaml --run_facts
python3 run.py --configs=dtwcns.yaml --run_dimensions
python3 run.py --configs=dw.yaml --run_dimensions





