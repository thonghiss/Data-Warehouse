SELECT
  b.register_id,
  b.invoice_id,
  'ns3'   AS company_code,
  a.number,
  a.employee_id,
  a.state AS register_payment_state,
  c.state AS invoice_state,
  c.type,
  a.cash_in_bank,
  a.payment_date,
  c.amount_total
FROM ccbs_register_payment AS a, account_invoice_ccbs_register_payment_rel AS b, account_invoice AS c
WHERE a.id = b.register_id
      AND b.invoice_id = c.id
      AND a.payment_date >= date_trunc('month', now()) - interval '1 month'