CREATE TABLE IF NOT EXISTS dim_register_payment (
  register_payment_id SERIAL PRIMARY KEY,
  register_id INTEGER ,
  invoice_id     INTEGER ,
  company_code    VARCHAR ,
  number       VARCHAR ,
  employee_id        INTEGER ,
  register_payment_state      VARCHAR ,
  invoice_state      VARCHAR ,
  type               VARCHAR ,
  cash_in_bank      BOOLEAN ,
  payment_date    TIMESTAMP ,
  amount_total     NUMERIC
)