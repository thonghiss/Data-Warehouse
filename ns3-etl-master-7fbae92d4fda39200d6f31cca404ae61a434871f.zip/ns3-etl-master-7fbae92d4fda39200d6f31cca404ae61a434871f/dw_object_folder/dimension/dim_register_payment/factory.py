from pygrametl.tables import TypeOneSlowlyChangingDimension

pygram_dim_register_payment_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_register_payment',
    "key": 'register_payment_id',
    "attributes": ['register_id', 'invoice_id', 'company_code', 'number', 'employee_id',
                   'register_payment_state', 'invoice_state', 'type',
                   'cash_in_bank', 'payment_date', 'amount_total'],
    "lookupatts": ['register_id', 'invoice_id', 'company_code'],
}