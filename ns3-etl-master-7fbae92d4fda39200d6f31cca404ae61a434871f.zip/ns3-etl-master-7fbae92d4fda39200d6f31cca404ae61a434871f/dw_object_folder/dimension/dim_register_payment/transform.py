from dw_object_folder.parent_class import TransformBase


class DimRegisterPayment(TransformBase):
    def run_class_function(self, object_name, data_source):
        # create transforming source
        print('done query and transform {}'.format(object_name))
        return data_source