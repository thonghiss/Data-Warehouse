SELECT
  rp.id          AS initial_id,
  rp.name,
  rp.ref,
  rp.is_company,
  rp.active,
  rp.customer,
  rp.supplier,
  rp.employee,
  rp.state,
  rp.seq,
  rp.seq_order,
  rp.street_id,
  area.name      AS area_name,
  CASE
  WHEN rp.street LIKE '%/%'
    THEN 'KH ngõ'
  WHEN rp.street LIKE '%ngõ%'
    THEN 'KH ngõ'
  WHEN rp.street LIKE '%Gác%'
    THEN 'KH ngõ'
  WHEN rp.street LIKE '%gác%'
    THEN 'KH ngõ'
  WHEN rp.street LIKE '%Tập Thể%'
    THEN 'KH ngõ'
  WHEN rp.street LIKE '%TT%'
    THEN 'KH ngõ'
  WHEN rp.street LIKE '%Ngõ%'
    THEN 'KH ngõ'
  WHEN cc_street.name LIKE '%Ngõ%'
    THEN 'KH ngõ'
  WHEN (rp.street IS NULL AND cc_street IS NULL)
    THEN 'Unknown'

  ELSE 'KH mặt phố'
  END            AS Classify,
  CASE
  WHEN rp.id IN (SELECT aaa.id
                 FROM
                   (SELECT
                      DISTINCT ON (table_1.id) table_1.id
                    FROM
                      (SELECT
                         rp.id,
                         CASE
                         WHEN line.name LIKE '%SH%'
                           THEN 'SH'
                         WHEN line.name LIKE '%HN%'
                           THEN 'HN'
                         WHEN line.name LIKE '%T5%'
                           THEN 'T5'
                         WHEN line.name LIKE '%SN%'
                           THEN 'SN'
                         WHEN line.name LIKE '%SX%'
                           THEN 'SX'
                         WHEN line.name LIKE '%DV%'
                           THEN 'DV'
                         ELSE 'N/A'
                         END AS service_type
                       FROM res_partner AS rp, account_invoice_line AS line
                       WHERE
                         rp.id = line.partner_id) table_1
                    WHERE table_1.service_type = 'SH'
                    ORDER BY table_1.id DESC) AS aaa
                   INNER JOIN
                   (SELECT table_1.id
                    FROM (
                           SELECT
                             rp.id,
                             CASE
                             WHEN line.name LIKE '%SH%'
                               THEN 'SH'
                             WHEN line.name LIKE '%HN%'
                               THEN 'HN'
                             WHEN line.name LIKE '%T5%'
                               THEN 'T5'
                             WHEN line.name LIKE '%SN%'
                               THEN 'SN'
                             WHEN line.name LIKE '%SX%'
                               THEN 'SX'
                             WHEN line.name LIKE '%DV%'
                               THEN 'DV'
                             ELSE 'N/A'
                             END AS service_type
                           FROM res_partner AS rp, account_invoice_line AS line
                           WHERE
                             rp.id = line.partner_id) AS table_1
                    GROUP BY table_1.id
                    HAVING count(DISTINCT table_1.service_type) = 1) AS bbb ON aaa.id = bbb.id)
    THEN TRUE
  ELSE FALSE END AS total_SH
FROM res_partner AS rp LEFT JOIN ccbs_location_street AS cc_street
    ON rp.street_id = cc_street.id
  LEFT JOIN ccbs_book AS book ON rp.book_id = book.id
  LEFT JOIN ccbs_location_area area ON book.area_id = area.id
ORDER BY rp.id DESC