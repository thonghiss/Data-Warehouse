CREATE TABLE IF NOT EXISTS dim_partner
(
  partner_id SERIAL  NOT NULL
    PRIMARY KEY,
  lookup_partner    VARCHAR,
  initial_id  INTEGER,
  company_code  VARCHAR,
  name       VARCHAR,
  ref        VARCHAR,
  is_company  BOOLEAN,
  active     BOOLEAN,
  customer   BOOLEAN,
  supplier   BOOLEAN,
  employee   BOOLEAN,
  state      VARCHAR,
  seq        INTEGER,
  seq_order  INTEGER,
  street_id  INTEGER,
  area_name  VARCHAR,
  classify   VARCHAR,
  total_sh   BOOLEAN
)