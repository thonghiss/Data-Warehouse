from pygrametl.tables import CachedDimension, TypeOneSlowlyChangingDimension, FactTable

# Partner Dimension
pygram_dim_partner_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_partner',
    "key": 'partner_id',
    "attributes": ['lookup_partner', 'initial_id', 'company_code', 'name', 'ref', 'is_company', 'active', 'customer',
                   'supplier',
                   'employee', 'state', 'seq',
                   'seq_order',
                   'street_id', 'area_name', 'classify', 'total_sh'],
    "lookupatts": ['lookup_partner']
}