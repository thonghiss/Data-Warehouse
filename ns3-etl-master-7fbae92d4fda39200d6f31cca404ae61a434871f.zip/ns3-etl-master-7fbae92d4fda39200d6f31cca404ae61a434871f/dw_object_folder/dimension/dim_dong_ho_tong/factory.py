from pygrametl.tables import TypeOneSlowlyChangingDimension

pygram_dim_dong_ho_tong_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_dong_ho_tong',
    "key": 'dong_ho_tong_id',
    "attributes": ['company_code', 'period_name', 'M3_cap_Ke_hoach',
                   'M3_cap_Thuc_te', 'period_month', 'period_year'],
    "lookupatts": ['company_code', 'period_name'],
}