CREATE TABLE IF NOT EXISTS dim_dong_ho_tong (
  dong_ho_tong_id SERIAL PRIMARY KEY,
  company_code    VARCHAR,
  period_name           VARCHAR ,
  M3_cap_Ke_hoach   NUMERIC ,
  M3_cap_Thuc_te  NUMERIC ,
  period_month       INTEGER ,
  period_year        INTEGER
)