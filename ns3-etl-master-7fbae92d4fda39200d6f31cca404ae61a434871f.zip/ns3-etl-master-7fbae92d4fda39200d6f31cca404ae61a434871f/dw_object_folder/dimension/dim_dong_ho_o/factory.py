from pygrametl.tables import TypeOneSlowlyChangingDimension

pygram_dim_dong_ho_o_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_dong_ho_o',
    "key": 'dong_ho_o_id',
    "attributes": ['company_code', 'period_name', 'area_name', 'M3_thu_Ke_hoach', 'M3_cap_Ke_hoach',
                   'Doanh_thu_Ke_hoach', 'M3_Thuc_te', 'period_month', 'period_year'],
    "lookupatts": ['company_code', 'period_name', 'area_name'],
}
