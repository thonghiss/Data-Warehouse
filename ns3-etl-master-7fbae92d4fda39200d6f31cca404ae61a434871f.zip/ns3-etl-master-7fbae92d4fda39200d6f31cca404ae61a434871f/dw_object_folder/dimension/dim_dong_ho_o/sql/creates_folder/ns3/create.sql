CREATE TABLE IF NOT EXISTS dim_dong_ho_o (
  dong_ho_o_id SERIAL PRIMARY KEY,
  company_code    VARCHAR,
  period_name           VARCHAR ,
  area_name               VARCHAR ,
  M3_thu_Ke_hoach   NUMERIC ,
  M3_cap_Ke_hoach   NUMERIC ,
  Doanh_thu_Ke_hoach  NUMERIC ,
  M3_Thuc_te        NUMERIC ,
  period_month       INTEGER ,
  period_year        INTEGER
)