import gspread
from oauth2client.service_account import ServiceAccountCredentials
import os

def handle_wrong_int_input(row_object):
    if row_object:
        try:
            int_object = int(row_object)
            return int_object
        except ValueError:
            int_object = int(row_object.replace(' ',''))
            return int_object
    else:
        row_object = 0
        return row_object

def py_source():
    # use creds to create a client to interact with the Google Drive API
    scope = ['https://www.googleapis.com/auth/spreadsheets.readonly', 'https://www.googleapis.com/auth/drive.readonly']
    creds = ServiceAccountCredentials.from_json_keyfile_name('client_secret.json', scope)
    client = gspread.authorize(creds)

    #open sheet by name
    sheet = client.open("NS3_BOD").worksheet("Đồng hồ ô (Kế hoạch+Thực tế)")

    # Extract and print all of the values
    dong_ho_o_source = sheet.get_all_records()

    # add and transform columns
    for row in dong_ho_o_source:
        row['company_code'] = os.getenv('SRC_COMPANY_CODE')
        row['period_month'] = int(row['Thang'][:-5])
        row['period_year'] = int(row['Thang'][-4:])
        row['period_name'] = row.pop('Thang')
        row['area_name'] = row.pop('O')
        row['M3_thu_Ke_hoach'] = handle_wrong_int_input(row['M3_thu_Ke_hoach'])
        row['M3_cap_Ke_hoach'] = handle_wrong_int_input(row['M3_cap_Ke_hoach'])
        row['Doanh_thu_Ke_hoach'] = handle_wrong_int_input(row['Doanh_thu_Ke_hoach'])
        row['M3_Thuc_te'] = handle_wrong_int_input(row['M3_Thuc_te'])

    return dong_ho_o_source