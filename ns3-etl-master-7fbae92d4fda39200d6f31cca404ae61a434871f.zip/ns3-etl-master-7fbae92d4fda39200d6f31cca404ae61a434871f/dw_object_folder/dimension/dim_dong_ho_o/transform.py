class DimDongHoO:
    def run_class_function(self):
        return None