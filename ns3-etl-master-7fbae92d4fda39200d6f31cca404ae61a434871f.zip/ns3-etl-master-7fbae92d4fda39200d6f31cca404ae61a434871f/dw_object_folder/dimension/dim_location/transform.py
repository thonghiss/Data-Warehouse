from pygrametl.datasources import TransformingSource
from dw_object_folder.parent_class import TransformBase


class DimLocation(TransformBase):
    # function to add area and country
    def add_area_country(self, row):
        '''add column'''
        row['country'] = 'Việt Nam'
        row['level1flag'] = False
        row['level2flag'] = False
        row['level3flag'] = False
        row['level4flag'] = False
        row['level5flag'] = False
        row['level6flag'] = False

    def run_class_function(self, object_name, data_source):
        # create transforming source
        final_source = TransformingSource(data_source, self.add_area_country, self.add_config_name)
        print('done query and transform {}'.format(object_name))
        return final_source