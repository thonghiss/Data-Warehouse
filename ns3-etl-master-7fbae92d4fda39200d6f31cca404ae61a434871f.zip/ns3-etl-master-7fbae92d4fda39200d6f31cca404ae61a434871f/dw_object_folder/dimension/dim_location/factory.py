from pygrametl.tables import CachedDimension, TypeOneSlowlyChangingDimension, FactTable

# Location Dimension
pygram_dim_location_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_location',
    "key": 'location_id',
    "attributes": ['lookup_location',
                   'initial_id',
                   'company_code',
                   'street',
                   'ward',
                   'district',
                   'city',
                   'area',
                   'country',
                   'level1flag',
                   'level2flag',
                   'level3flag',
                   'level4flag',
                   'level5flag',
                   'level6flag',
                   ],
    "lookupatts": ['lookup_location']
}