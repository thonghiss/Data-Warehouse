CREATE TABLE IF NOT EXISTS dim_location (
  location_id SERIAL PRIMARY KEY,
  lookup_location   VARCHAR,
  initial_id  INTEGER,
  company_code  VARCHAR,
  street      VARCHAR(512),
  ward        VARCHAR(45),
  district    VARCHAR(45),
  city        VARCHAR(45),
  area        VARCHAR(45),
  country     VARCHAR(45),
  level1flag  BOOLEAN DEFAULT FALSE,
  level2flag  BOOLEAN DEFAULT FALSE,
  level3flag  BOOLEAN DEFAULT FALSE,
  level4flag  BOOLEAN DEFAULT FALSE,
  level5flag  BOOLEAN DEFAULT FALSE,
  level6flag  BOOLEAN DEFAULT FALSE
)