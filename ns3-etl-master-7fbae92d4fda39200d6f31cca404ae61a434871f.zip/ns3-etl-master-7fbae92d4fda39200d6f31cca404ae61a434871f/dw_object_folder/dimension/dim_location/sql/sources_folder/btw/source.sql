SELECT
  id   AS initial_id,
  name AS street,
  'unknown' AS ward,
  'unknown' AS district,
  'Bình Thuận' AS city,
  'Miền Trung' AS area
FROM
  ccbs_location_street