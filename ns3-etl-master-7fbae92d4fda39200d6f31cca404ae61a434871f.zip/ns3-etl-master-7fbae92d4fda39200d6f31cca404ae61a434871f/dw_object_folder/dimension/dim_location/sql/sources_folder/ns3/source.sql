SELECT
  s.id   AS initial_id,
  s.name AS street,
  w.name AS ward,
  d.name AS district,
  c.name AS city,
  'Miền Bắc' AS area
FROM
  ccbs_location_street s,
  ccbs_location_ward w,
  ccbs_location_district d,
  ccbs_location_city c
WHERE
  s.ward_id = w.id
  AND w.district_id = d.id
  AND d.city_id = c.id
