import pandas as pd
from pygrametl.datasources import TransformingSource, PandasSource
import numpy as np
from dw_object_folder.parent_class import TransformBase



class DimProcessIntegration(TransformBase):
    # return the function of two point on graph
    def f(self, x, point_1=[], point_2=[]):
        delta_y = point_2[1] - point_1[1]
        delta_x = point_2[0] - point_1[0]
        if delta_x == 0:
            delta_x = 0.01

        a = delta_y / delta_x
        b = point_1[1] - a * point_1[0]
        y = a * x + b
        return y

    def dimension_integration(self, row):
        if row['next_epoch'] == 0 and row['next_count_number_cumulative'] == 0:
            area = 0
        else:
            row['next_count_number_cumulative'] = int(row['next_count_number_cumulative'])
            row['count_number_cumulative'] = int(row['count_number_cumulative'])
            n = abs(row['epoch'] - row['next_epoch']) + 1
            t = np.linspace(row['epoch'], row['next_epoch'], n)
            fx = self.f(t, point_1=[row['epoch'], row['count_number_cumulative']],
                        point_2=[row['next_epoch'], row['next_count_number_cumulative']])
            area = np.sum(fx) * abs((row['epoch'] - row['next_epoch'])) / n
        return area

    def run_class_function(self, object_name, data_source):

        # create dataframe
        df = pd.DataFrame(data_source)
        if len(df) == 0:
            print('no record in query period')
        else:
            # pandas transformation

            df = df.sort_values(by=['epoch'])
            group_df = df.groupby(['company_code','period_name'])
            df['count_number_cumulative'] = group_df['count_number'].apply(lambda x: x.cumsum())
            df = df.assign(next_epoch=group_df['epoch'].shift(-1))
            df = df.assign(next_count_number_cumulative=group_df['count_number_cumulative'].shift(-1))

            df['next_epoch'].fillna(0, inplace=True)
            df['next_count_number_cumulative'].fillna(0, inplace=True)
            df['area_integration'] = df.apply(self.dimension_integration, axis=1)


        # create pandasSource
        final_source = PandasSource(df)
        print('done query and transform {}'.format(object_name))
        return final_source