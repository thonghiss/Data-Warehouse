from pygrametl.tables import TypeOneSlowlyChangingDimension

pygram_dim_process_integration_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_process_integration',
    "key": 'process_integration_id',
    "attributes": ['company_code', 'period_name', 'epoch', 'count_number', 'count_number_cumulative',
                   'next_epoch', 'next_count_number_cumulative', 'area_integration'],
    "lookupatts": ['company_code', 'epoch'],
}