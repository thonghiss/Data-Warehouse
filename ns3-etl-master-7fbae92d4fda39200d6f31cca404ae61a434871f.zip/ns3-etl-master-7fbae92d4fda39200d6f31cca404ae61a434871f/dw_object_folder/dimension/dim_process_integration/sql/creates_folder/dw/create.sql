CREATE TABLE IF NOT EXISTS dim_process_integration (
  process_integration_id SERIAL PRIMARY KEY,
  company_code VARCHAR,
  period_name     VARCHAR ,
  epoch    DOUBLE PRECISION,
  count_number       NUMERIC ,
  count_number_cumulative        NUMERIC ,
  next_epoch      DOUBLE PRECISION ,
  next_count_number_cumulative      NUMERIC,
  area_integration       NUMERIC
)