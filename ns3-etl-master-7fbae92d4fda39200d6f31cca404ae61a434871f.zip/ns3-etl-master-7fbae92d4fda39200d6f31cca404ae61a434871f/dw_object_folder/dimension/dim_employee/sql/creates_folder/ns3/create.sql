CREATE TABLE IF NOT EXISTS dim_employee (
  employee_id SERIAL PRIMARY KEY,
  lookup_employee VARCHAR,
  initial_id     INTEGER,
  company_code    VARCHAR,
  login       VARCHAR,
  name        VARCHAR(128),
  active      BOOLEAN DEFAULT TRUE,
  mobile      VARCHAR(16),
  email       VARCHAR(64)
)