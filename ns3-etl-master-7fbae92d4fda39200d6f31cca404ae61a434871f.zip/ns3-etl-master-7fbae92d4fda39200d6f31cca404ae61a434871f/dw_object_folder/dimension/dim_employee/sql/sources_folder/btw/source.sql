SELECT
  ru.id AS initial_id,
  ru.login,
  rp.name,
  ru.active,
  rp.mobile,
  rp.email
FROM res_users ru, res_partner rp
WHERE ru.partner_id = rp.id