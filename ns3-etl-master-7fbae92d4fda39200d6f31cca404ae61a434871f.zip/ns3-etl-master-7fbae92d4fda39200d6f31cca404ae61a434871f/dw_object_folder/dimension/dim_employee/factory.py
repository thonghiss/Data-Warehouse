from pygrametl.tables import TypeOneSlowlyChangingDimension

pygram_dim_employee_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_employee',
    "key": 'employee_id',
    "attributes": ['lookup_employee', 'initial_id', 'company_code', 'login', 'name', 'active', 'mobile', 'email'],
    "lookupatts": ['lookup_employee']
}