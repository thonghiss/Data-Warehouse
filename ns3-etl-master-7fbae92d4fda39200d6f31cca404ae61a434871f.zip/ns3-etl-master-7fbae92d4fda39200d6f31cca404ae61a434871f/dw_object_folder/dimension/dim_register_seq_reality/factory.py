from pygrametl.tables import TypeOneSlowlyChangingDimension

pygram_dim_register_seq_reality_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_register_seq_reality',
    "key": 'register_seq_reality_id',
    "attributes": ['company_code', 'period_name', 'register_user_id', 'register_route_id', 'count_true_partner',
                   'count_false_partner', 'period_year',
                   'period_month'],
    "lookupatts": ['company_code', 'period_name', 'register_user_id', 'register_route_id'],
}