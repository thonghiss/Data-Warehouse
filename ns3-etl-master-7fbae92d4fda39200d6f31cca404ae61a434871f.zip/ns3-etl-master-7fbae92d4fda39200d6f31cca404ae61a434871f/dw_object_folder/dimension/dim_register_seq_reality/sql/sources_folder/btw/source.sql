SELECT
  a.id as transaction_id,
  a.partner_id,
  period.name   AS period_name,
  a.register_user_id,
  c.register_route_id,
  a.result_date AS date
FROM ccbs_transaction AS a, res_partner AS c, ccbs_period AS period
WHERE a.partner_id = c.id
      AND a.period_id = period.id
      AND a.result_date >= date_trunc('month', now()) - interval '1 month'
      AND a.register_user_id IS NOT NULL
      AND a.partner_id IS NOT NULL