CREATE TABLE IF NOT EXISTS dim_register_seq_reality
(
  register_seq_reality_id SERIAL  NOT NULL
    PRIMARY KEY,
--   transaction_id      INTEGER,
  company_code        VARCHAR,
  period_name         VARCHAR,
  register_user_id    INTEGER,
  register_route_id     INTEGER,
--   partner_id      INTEGER ,
--   result_date TIMESTAMP,
--   validate_queue BOOLEAN,
  count_true_partner  NUMERIC,
  count_false_partner  NUMERIC,
--   list_of_false_partner   VARCHAR,
  period_year     INTEGER,
  period_month    INTEGER
)