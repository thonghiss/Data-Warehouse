import pandas as pd
from pygrametl.datasources import TransformingSource, PandasSource
import numpy as np
from dw_object_folder.parent_class import TransformBase



class DimRegisterSeqReality(TransformBase):
    # function to validate the first queue
    def validate_queue(self, row):
        src_company_code = self.get_company_code()
        if src_company_code == 'ns3':
            if row['previous_date_epoch'] == 0 and row['next_date_epoch'] == 0:
                validate = True
            elif abs(row['date_epoch'] - row['previous_date_epoch']) <= 600 or abs(
                    row['date_epoch'] - row['next_date_epoch']) <= 600:
                validate = True
            else:
                validate = False
        elif src_company_code == 'btw':
            if row['previous_date_epoch'] == 0 and row['next_date_epoch'] == 0:
                validate = True
            elif abs(row['date_epoch'] - row['previous_date_epoch']) <= 1800 or abs(
                    row['date_epoch'] - row['next_date_epoch']) <= 1800:
                validate = True
            else:
                validate = False
        return validate

    # function to return partner_id of false validate
    def false_partner(self, row):
        if row['validate_queue'] is False:
            false_partner_value = str(row['partner_id'])
        else:
            false_partner_value = np.nan
        return false_partner_value

    def run_class_function(self, object_name, data_source):
        # create transforming source
        transforming_source = TransformingSource(data_source, self.datetime_to_epoch, self.add_month_and_year)

        # create dataframe
        df = pd.DataFrame(transforming_source)
        if len(df) == 0:
            print('no record in query period')
        else:
            # pandas transformation
            df.sort_values(by=['date_epoch'], inplace=True)
            group_df = df.groupby(['period_name', 'register_user_id', 'register_route_id'])

            df = df.assign(next_date_epoch=group_df['date_epoch'].shift(-1))
            df = df.assign(previous_date_epoch=group_df['date_epoch'].shift(1))

            df['next_date_epoch'].fillna(0, inplace=True)
            df['previous_date_epoch'].fillna(0, inplace=True)

            df['validate_queue'] = df.apply(self.validate_queue, axis=1)
            df['false_partner'] = df.apply(self.false_partner, axis=1)

            group_df = df.groupby(['period_name', 'register_user_id', 'register_route_id'])
            df['count_true_partner'] = group_df['validate_queue'].transform('sum')
            df['count_false_partner'] = group_df['transaction_id'].transform('count') - group_df[
                'validate_queue'].transform(
                'sum')

            # group_df = df.groupby(['period_name', 'register_user_id', 'register_route_id'])
            # if df['count_false_partner'] == 0:
            #     df['list_of_false_partner'] = 0
            # else:
            #     df['list_of_false_partner'] = group_df['false_partner'].transform(lambda x: ','.join(x))

            df['company_code'] = self.get_company_code()
            df = group_df.head(1)

        # create pandasSource
        final_source = PandasSource(df)
        print('done query and transform {}'.format(object_name))
        return final_source