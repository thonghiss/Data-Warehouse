CREATE TABLE IF NOT EXISTS dim_partner_status
(
  partner_status_id SERIAL  NOT NULL
    PRIMARY KEY,
  partner_id    INTEGER ,
  period_name  VARCHAR ,
  company_code  VARCHAR,
  area_name       VARCHAR,
  code        VARCHAR,
  number_total  NUMERIC ,
  period_month     INTEGER ,
  period_year   INTEGER
)