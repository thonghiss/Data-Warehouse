SELECT
  a.partner_id,
  b.name              AS period_name,
  d.name              AS area_name,
  e.code,
  sum(a.number_total) AS number_total
FROM ccbs_transaction AS a, ccbs_period AS b, ccbs_book AS c, ccbs_location_area AS d, ccbs_meter_status AS e
WHERE a.period_id = b.id
      AND a.book_id = c.id
      AND c.area_id = d.id
      AND a.status_id = e.id
      AND b.year = date_part('year', now())
      AND b.period = date_part('month', now())
GROUP BY 1, 2, 3, 4;