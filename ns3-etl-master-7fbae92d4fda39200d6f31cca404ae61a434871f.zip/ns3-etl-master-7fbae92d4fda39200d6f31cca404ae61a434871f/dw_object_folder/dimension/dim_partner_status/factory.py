from pygrametl.tables import TypeOneSlowlyChangingDimension

pygram_dim_partner_status_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_partner_status',
    "key": 'partner_status_id',
    "attributes": ['partner_id', 'period_name', 'company_code', 'area_name', 'code', 'number_total',
                   'period_month','period_year'],
    "lookupatts": ['partner_id','period_name','company_code']
}