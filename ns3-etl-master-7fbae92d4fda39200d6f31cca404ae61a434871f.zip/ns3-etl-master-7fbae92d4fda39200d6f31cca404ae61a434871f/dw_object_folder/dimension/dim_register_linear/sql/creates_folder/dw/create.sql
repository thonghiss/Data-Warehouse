CREATE TABLE IF NOT EXISTS dim_register_linear (
  register_linear_id SERIAL PRIMARY KEY,
  company_code VARCHAR,
  period_name     VARCHAR ,
  day_of_month    INTEGER ,
  total_count       NUMERIC ,
  slope        NUMERIC ,
  intercept      NUMERIC ,
  y_value_of_dom_on_linear      NUMERIC ,
  distance_to_linear      NUMERIC,
  period_month    INTEGER ,
  period_year     INTEGER
)