SELECT
  company_code,
  datetime.period AS period_name,
  datetime.day_of_month,
  sum(fact.count_number) AS total_count
FROM fact_register_user AS fact, dim_datetime AS datetime, dim_company AS company
WHERE fact.datetime_id = datetime.datetime_id AND fact.company_id = company.company_id
GROUP BY 1, 2, 3