from pygrametl.tables import TypeOneSlowlyChangingDimension

pygram_dim_register_linear_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_register_linear',
    "key": 'register_linear_id',
    "attributes": ['company_code', 'period_name', 'day_of_month', 'total_count', 'slope',
                   'intercept', 'y_value_of_dom_on_linear',
                   'distance_to_linear', 'period_year', 'period_month'],
    "lookupatts": ['company_code', 'period_name', 'day_of_month'],
}