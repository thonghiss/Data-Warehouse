from pygrametl.datasources import TransformingSource, PandasSource
import pandas as pd
from scipy import stats
import math
from dw_object_folder.parent_class import TransformBase


class DimRegisterLinear(TransformBase):

    # function to calculate linear regression
    def linear_regression(self, groupby_object):
        x = groupby_object['day_of_month']
        y = groupby_object['total_count']

        slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
        groupby_object['slope'] = slope
        groupby_object['intercept'] = intercept
        return groupby_object

    # function to get y_value_of_dom_on_linear
    def get_y_value_of_dom_on_linear(self, row):
        row['y_value_of_dom_on_linear'] = row['slope'] * row['day_of_month'] + row['intercept']
        return row

    # function to get shortest distance between a point and a line (slope and intercep)
    def get_shortest_distanct(self,row):
        a = row['slope']
        b = -1
        c = row['intercept']
        x = row['day_of_month']
        y = row['total_count']

        row['distance_to_linear'] = abs((a * x + b * y + c)) / (math.sqrt(a * a + b * b))
        return row

    # function to get

    def run_class_function(self, object_name, data_source):
        # create transforming source
        transforming_source = TransformingSource(data_source, self.add_month_and_year)

        # create dataframe
        df = pd.DataFrame(transforming_source)
        if len(df) == 0:
            print('no record in query period')
        else:
            # pandas transformation
            df["total_count"] = pd.to_numeric(df["total_count"])

            group_df = df.groupby(['company_code', 'period_name'])

            df = group_df.apply(lambda x: self.linear_regression(x))

            df = df.apply(self.get_y_value_of_dom_on_linear, axis=1)

            df = df.apply(self.get_shortest_distanct, axis=1)


        # create pandasSource
        final_source = PandasSource(df)
        print('done query and transform {}'.format(object_name))
        return final_source
