from pygrametl.tables import TypeOneSlowlyChangingDimension

# call_center Dimension
pygram_dim_call_center_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_call_center',
    "key": 'call_center_id',
    "attributes": ['lookup_callcenter', 'initial_id', 'company_code', 'customer_id', 'call_id', 'path',
                   'path_download', 'caller', 'called', 'user_id', 'agent_id', 'group_id', 'call_type', 'start_time',
                   'call_status', 'end_time', 'wait_time', 'hold_time', 'talk_time', 'end_status'],
    "lookupatts": ['lookup_callcenter']
}
