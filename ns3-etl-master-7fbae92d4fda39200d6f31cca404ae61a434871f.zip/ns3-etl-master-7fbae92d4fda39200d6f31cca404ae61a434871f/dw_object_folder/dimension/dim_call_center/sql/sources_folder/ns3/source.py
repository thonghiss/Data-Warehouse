import requests
import time
import os


def py_source():
    call_center_source = []

    url = 'https://vcc-web1.vinaphone.com.vn/0842001155/api/v1/calls?start_time_since=2019-01-01&page=1&count=1000&order_by= start_time&order_type=desc'
    access_token = 'oG9kM2R5IvQqk7M'

    response = requests.get(url=url, headers={'Content-Type': 'application/json',
                                              'Authorization': 'Bearer {}'.format(access_token)})

    calls = response.json()['calls']

    for call in calls:
        # change the name of id to initial_id
        call['initial_id'] = call.pop('id')

        # add new column
        call['company_code'] = os.getenv('SRC_COMPANY_CODE')

        call['lookup_callcenter'] = call['initial_id'] + '_' + call['company_code']

        # edit the type of value
        call['initial_id'] = int(call['initial_id'])
        call['customer_id'] = int(call['customer_id'])
        call['group_id'] = int(call['group_id'])
        call['call_type'] = int(call['call_type'])

        wait_time = time.strptime(call['wait_time'], "%H:%M:%S")
        call['wait_time'] = wait_time.tm_hour * 3600 + wait_time.tm_min * 60 + wait_time.tm_sec

        hold_time = time.strptime(call['hold_time'], "%H:%M:%S")
        call['hold_time'] = hold_time.tm_hour * 3600 + hold_time.tm_min * 60 + hold_time.tm_sec

        talk_time = time.strptime(call['talk_time'], "%H:%M:%S")
        call['talk_time'] = talk_time.tm_hour * 3600 + talk_time.tm_min * 60 + talk_time.tm_sec

        # handle null value
        if 'path' in call:
            pass
        else:
            call['path'] = None

        if 'path_download' in call:
            pass
        else:
            call['path_download'] = None

        call_center_source.append(call)

    return call_center_source
