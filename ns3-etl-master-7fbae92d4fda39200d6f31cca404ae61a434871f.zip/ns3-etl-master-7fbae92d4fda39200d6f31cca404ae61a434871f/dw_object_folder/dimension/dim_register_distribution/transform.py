import pandas as pd
from pygrametl.datasources import TransformingSource, PandasSource
from dw_object_folder.parent_class import TransformBase


class DimRegisterDistribution(TransformBase):
    def run_class_function(self, object_name, data_source):
        # create transforming source
        transforming_source = TransformingSource(data_source, self.add_month_and_year)

        # create dataframe
        df = pd.DataFrame(transforming_source)
        if len(df) == 0:
            print('no record in query period')
        else:
            # pandas transformation
            df['max_period'] = df[['early_morning', 'morning', 'afternoon', 'evening']].max(axis=1)
            df['type_period'] = df[['early_morning', 'morning', 'afternoon', 'evening']].idxmax(axis=1)

            group_df_alltime = df.groupby(['register_user_id'])
            df['sum_early_morning_alltime'] = group_df_alltime['early_morning'].transform('sum')
            df['sum_morning_alltime'] = group_df_alltime['morning'].transform('sum')
            df['sum_afternoon_alltime'] = group_df_alltime['afternoon'].transform('sum')
            df['sum_evening_alltime'] = group_df_alltime['evening'].transform('sum')
            df['max_period_alltime'] = df[['sum_early_morning_alltime', 'sum_morning_alltime', 'sum_afternoon_alltime',
                                           'sum_evening_alltime']].max(
                axis=1)
            df['type_period_alltime'] = df[['sum_early_morning_alltime', 'sum_morning_alltime', 'sum_afternoon_alltime',
                                            'sum_evening_alltime']].idxmax(axis=1).str[4:-8]
            df['company_code'] = self.get_company_code()

        # create pandasSource
        final_source = PandasSource(df)
        print('done query and transform {}'.format(object_name))
        return final_source
