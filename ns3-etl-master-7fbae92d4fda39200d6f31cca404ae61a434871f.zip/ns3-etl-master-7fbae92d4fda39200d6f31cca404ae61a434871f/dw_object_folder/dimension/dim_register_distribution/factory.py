from pygrametl.tables import TypeOneSlowlyChangingDimension

pygram_dim_register_distribution_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_register_distribution',
    "key": 'register_distribution_id',
    "attributes": ['register_user_id', 'period_name', 'company_code', 'period_month',
                   'period_year', 'early_morning', 'morning', 'afternoon', 'evening', 'max_period', 'type_period',
                   'sum_early_morning_alltime', 'sum_morning_alltime', 'sum_afternoon_alltime', 'sum_evening_alltime',
                   'max_period_alltime', 'type_period_alltime'],
    "lookupatts": ['register_user_id', 'period_name', 'company_code'],
}