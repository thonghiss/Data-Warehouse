CREATE TABLE IF NOT EXISTS dim_register_distribution
(
  register_distribution_id SERIAL  NOT NULL
    PRIMARY KEY,
  register_user_id         INTEGER,
  period_name     VARCHAR,
  company_code    VARCHAR,
  period_month    INTEGER,
  period_year     INTEGER,
  early_morning     INTEGER ,
  morning    INTEGER,
  afternoon     INTEGER,
  evening    INTEGER,
  max_period  INTEGER,
  type_period VARCHAR,
  sum_early_morning_alltime   INTEGER,
  sum_morning_alltime   INTEGER,
  sum_afternoon_alltime INTEGER,
  sum_evening_alltime   INTEGER,
  max_period_alltime           INTEGER,
  type_period_alltime   VARCHAR
)