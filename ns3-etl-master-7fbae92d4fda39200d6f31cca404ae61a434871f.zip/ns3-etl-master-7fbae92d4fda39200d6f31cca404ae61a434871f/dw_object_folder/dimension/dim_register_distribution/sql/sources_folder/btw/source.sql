SELECT
  a.register_user_id,
  b.name                                                                   AS period_name,
  count(a.id)
    FILTER (WHERE date_part('hour', a.result_date) BETWEEN 17 AND 22)      AS early_morning,
  count(a.id)
    FILTER (WHERE date_part('hour', a.result_date) IN (23, 0, 1, 2, 3, 4)) AS morning,
  count(a.id)
    FILTER (WHERE date_part('hour', a.result_date) BETWEEN 5 AND 10)       AS afternoon,
  count(a.id)
    FILTER (WHERE date_part('hour', a.result_date) BETWEEN 11 AND 16)      AS evening
FROM ccbs_transaction AS a, ccbs_period AS b
WHERE a.period_id = b.id
      AND a.result_date IS NOT NULL
      AND a.register_user_id IS NOT NULL
      AND a.result_date >= date_trunc('month', now()) - interval '1 month'
GROUP BY 1, 2