from pygrametl.tables import TypeOneSlowlyChangingDimension

# Company Dimension
pygram_dim_company_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_company',
    "key": 'company_id',
    "attributes": ['company_code', 'company_name'],
    "lookupatts": ['company_code']
}

