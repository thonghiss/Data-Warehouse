def py_source():
    companySource = []
    list_company = [['ns3', 'Nước Sạch 3'], ['btw', 'Bình Thuận'], ['bgw', 'Bắc Giang']]
    for item in list_company:
        row = {'company_code': item[0], 'company_name': item[1]}
        companySource.append(row)
    return companySource