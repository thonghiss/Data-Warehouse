CREATE TABLE IF NOT EXISTS dim_company (
          company_id  SERIAL PRIMARY KEY,
          company_code       VARCHAR,
          company_name       VARCHAR
          )
