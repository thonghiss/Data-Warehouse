CREATE TABLE IF NOT EXISTS dim_hoa_don_tai_chinh (
  hoa_don_tai_chinh_id SERIAL PRIMARY KEY,
  company_code    VARCHAR,
  period_name           VARCHAR ,
  area_name         VARCHAR ,
  Doanh_thu   NUMERIC ,
  m3  NUMERIC ,
  period_month       INTEGER ,
  period_year        INTEGER
)