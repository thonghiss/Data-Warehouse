from pygrametl.tables import TypeOneSlowlyChangingDimension

pygram_dim_hoa_don_tai_chinh_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_hoa_don_tai_chinh',
    "key": 'hoa_don_tai_chinh_id',
    "attributes": ['company_code', 'period_name', 'area_name', 'Doanh_thu',
                   'm3', 'period_month', 'period_year'],
    "lookupatts": ['company_code', 'period_name', 'area_name'],
}
