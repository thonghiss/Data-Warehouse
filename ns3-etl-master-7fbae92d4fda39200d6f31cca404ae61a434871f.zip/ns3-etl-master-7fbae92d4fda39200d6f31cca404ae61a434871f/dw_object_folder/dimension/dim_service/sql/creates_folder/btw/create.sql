CREATE TABLE IF NOT EXISTS dim_service
(
  service_id SERIAL  NOT NULL
    PRIMARY KEY,
  service_name   VARCHAR,
  period_name         VARCHAR ,
  company_code  VARCHAR,
  quantity  NUMERIC,
  period_month  INTEGER ,
  period_year   INTEGER
)