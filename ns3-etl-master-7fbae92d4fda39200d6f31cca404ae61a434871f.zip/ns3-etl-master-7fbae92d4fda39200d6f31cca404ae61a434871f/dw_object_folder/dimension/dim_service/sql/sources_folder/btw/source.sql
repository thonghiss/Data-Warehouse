SELECT
  NULL AS service_name,
  NULL AS period_name,
  NULL AS type,
  NULL AS initial_quantity;