SELECT
  a.name                                                                             AS service_name,
  concat(date_part('month', b.date_invoice), '/', date_part('year', b.date_invoice)) AS period_name,
  b.type,
  sum(a.quantity)                                                                    AS initial_quantity
FROM account_invoice_line AS a, account_invoice AS b
WHERE a.invoice_id = b.id
      AND b.state IN ('paid', 'open')
      AND b.type IN ('out_invoice', 'out_refund')
      AND b.date_invoice >= '2018-09-01'
GROUP BY 1, 2, 3;