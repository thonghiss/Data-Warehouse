from pygrametl.tables import TypeOneSlowlyChangingDimension

pygram_dim_service_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_service',
    "key": 'service_id',
    "attributes": ['service_name', 'period_name', 'company_code', 'quantity','period_year','period_month'],
    "lookupatts": ['service_name', 'period_name', 'company_code'],
}
