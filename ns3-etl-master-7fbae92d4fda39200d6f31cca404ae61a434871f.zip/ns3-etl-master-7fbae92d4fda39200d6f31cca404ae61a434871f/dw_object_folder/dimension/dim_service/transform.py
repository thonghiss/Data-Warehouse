from pygrametl.datasources import TransformingSource, PandasSource
import pandas as pd
from dw_object_folder.parent_class import TransformBase


class DimService(TransformBase):

    # function to handle null value of out invoice and out refund
    def handle_null_type(self,input_list):
        if input_list == []:
            result = 0
        else:
            result = input_list[0]
        return result


    # function to calculate quantity column (out invoice - out refund)
    def get_quantity(self, groupby_object):

        list_invoice_quantity = list(groupby_object[groupby_object['type'] == 'out_invoice']['initial_quantity'].values)
        out_invoice_quantity = self.handle_null_type(list_invoice_quantity)

        list_refund_quantity = list(groupby_object[groupby_object['type'] == 'out_refund']['initial_quantity'].values)
        out_refund_quantity = self.handle_null_type(list_refund_quantity)

        groupby_object['quantity'] = out_invoice_quantity - out_refund_quantity

        return groupby_object

    def run_class_function(self, object_name, data_source):
        # # create transforming source
        # transforming_source = TransformingSource(data_source, self.add_month_and_year)

        # create dataframe
        df = pd.DataFrame(data_source)
        if len(df) == 0:
            print('no record in query period')
        else:
            # pandas transformation
            df['company_code'] = self.get_company_code()

            group_df = df.groupby(['company_code', 'service_name','period_name'])

            df = group_df.apply(lambda x: self.get_quantity(x))

        # create pandasSource
        pandas_source = PandasSource(df)
        final_source = TransformingSource(pandas_source, self.add_month_and_year)

        print('done query and transform {}'.format(object_name))
        return final_source