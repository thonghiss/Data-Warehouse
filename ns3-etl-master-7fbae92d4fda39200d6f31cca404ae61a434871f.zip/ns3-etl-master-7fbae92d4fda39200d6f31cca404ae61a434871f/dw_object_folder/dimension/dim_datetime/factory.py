from pygrametl.tables import CachedDimension


# Datetime Dimension
pygram_dim_datetime_factory = {
    "class": CachedDimension,
    "name": 'dim_datetime',
    "key": 'datetime_id',
    "attributes": ['epoch',
                   'minute',
                   'minute_20',
                   'minute_30',
                   'hour',
                   'day_of_week',
                   'day_of_month',
                   'week',
                   'month',
                   'year',
                   'period'
                   # 'holiday',
                   # 'working_time'
                   ],
    "lookupatts": ['epoch']
}
