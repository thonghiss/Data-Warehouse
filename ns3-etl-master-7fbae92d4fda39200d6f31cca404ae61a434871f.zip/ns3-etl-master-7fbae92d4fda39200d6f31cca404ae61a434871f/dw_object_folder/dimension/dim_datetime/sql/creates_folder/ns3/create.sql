CREATE TABLE IF NOT EXISTS dim_datetime (
          datetime_id  SERIAL PRIMARY KEY,
          epoch        FLOAT, --second since 01-01-1970
          minute       INTEGER, --0 - 10 - 20 - 30 - 40 - 50,
          minute_20    INTEGER, --0 - 1 - 2,
          minute_30    INTEGER, --0 - 1,
          hour         INTEGER, --0-23
          day_of_week  INTEGER, -- 1-7
          day_of_month INTEGER, -- 1-31
          week         INTEGER, -- 1-52
          month        INTEGER, -- 1-12
          year         INTEGER, -- 2018 - 2022
          --quarter integer, --1-4
          -- day_name varchar(12),
          -- day_abbr varchar(12),
          -- month_name varchar(12),
          -- month_abbr varchar(12),
          -- working_day_flag boolean, --Ngay nghi hay ngay lam viec
          period       VARCHAR(16) -- 12-2018
          )
