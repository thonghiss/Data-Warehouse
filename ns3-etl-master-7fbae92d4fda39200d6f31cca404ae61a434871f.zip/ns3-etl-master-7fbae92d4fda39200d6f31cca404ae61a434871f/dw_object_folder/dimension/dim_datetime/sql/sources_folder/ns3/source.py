import datetime
import time
from calendar import timegm
import calendar


def py_source():
    minutes = [0, 10, 20, 30, 40, 50]
    hours = range(0, 24)
    dates = range(1, 32)
    months = range(1, 13)
    years = range(2018, 2023)

    datetimeSource = []

    def is_validate_date(y, m, d):
        r = True
        if m in (4, 6, 9, 11) and d == 31:
            r = False
        if m == 2 and d > 29:
            r = False
        if m == 2 and d == 29:
            if not calendar.isleap(y):
                r = False
        return r

    for y in years:
        for m in months:
            for d in dates:
                if not is_validate_date(y, m, d):
                    continue
                for h in hours:
                    for mi in minutes:
                        row = {'year': y, 'month': m, 'day_of_month': d, 'hour': h, 'minute': mi}
                        # t = "{}-{}-{}-{}-{}".format(y, m, d, h, m)
                        t = datetime.datetime(y, m, d, h, m, 0)
                        row['day_of_week'] = t.weekday() + 1
                        row['week'] = t.isocalendar()[1]
                        row['period'] = '{}-{}'.format(m, y)

                        utc_time = time.strptime("{}-{}-{}T{}:{}:{}.000Z".format(y, m, d, h, mi, 0),
                                                 "%Y-%m-%dT%H:%M:%S.%fZ")
                        row['epoch'] = timegm(utc_time)
                        if mi in [0, 10]:
                            row['minute_20'] = 0
                            row['minute_30'] = 0
                        if mi == 20:
                            row['minute_20'] = 1
                            row['minute_30'] = 0
                        if mi == 30:
                            row['minute_20'] = 1
                            row['minute_30'] = 1
                        if mi in [40, 50]:
                            row['minute_20'] = 2
                            row['minute_30'] = 1
                        datetimeSource.append(row)
    return datetimeSource