from pygrametl.datasources import TransformingSource, PandasSource
from dw_object_folder.parent_class import TransformBase
import pandas as pd


class DimRegisterAlert(TransformBase):
    def run_class_function(self, object_name, data_source):
        # create dataframe
        df = pd.DataFrame(data_source)

        if len(df) == 0:
            print('no record in query period')
        else:
            # pandas transformation
            df = df.groupby(['company_code', 'group_of_days', 'group_of_hours'])['sum_number'].agg(
                ['min', 'max']).reset_index()
            df.rename({'min': 'min_number', 'max': 'max_number'}, axis=1, inplace=True)

        # create pandasSource
        final_source = PandasSource(df)
        print('done query and transform {}'.format(object_name))
        return final_source
