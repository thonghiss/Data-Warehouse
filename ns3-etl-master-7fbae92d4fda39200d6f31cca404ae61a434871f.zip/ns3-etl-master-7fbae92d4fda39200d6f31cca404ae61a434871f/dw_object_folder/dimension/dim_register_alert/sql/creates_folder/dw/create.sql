CREATE TABLE IF NOT EXISTS dim_register_alert (
  register_alert_id SERIAL PRIMARY KEY,
  company_code VARCHAR,
  group_of_days    VARCHAR ,
  group_of_hours    VARCHAR ,
  min_number       NUMERIC ,
  max_number       NUMERIC
)