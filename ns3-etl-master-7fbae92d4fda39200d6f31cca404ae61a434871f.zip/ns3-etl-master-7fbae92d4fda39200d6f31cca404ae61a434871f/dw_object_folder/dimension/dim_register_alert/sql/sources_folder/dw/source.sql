SELECT
  c.company_code,
  b.month,
  b.day_of_month,
  CASE
  WHEN b.day_of_month BETWEEN 1 AND 10
    THEN 'period 1-10'
  ELSE 'period 11-31'
  END AS group_of_days,
  CASE
  WHEN b.hour BETWEEN 17 AND 22
    THEN 'early_morning'
  WHEN b.hour IN (23, 0, 1, 2, 3, 4)
    THEN 'morning'
  WHEN b.hour BETWEEN 5 AND 10
    THEN 'afternoon'
  WHEN b.hour BETWEEN 11 AND 16
    THEN 'evening'
  END AS group_of_hours,
  sum(a.count_number) AS sum_number
FROM fact_register_user AS a, dim_datetime AS b, dim_company AS c
WHERE a.datetime_id = b.datetime_id
      AND a.company_id = c.company_id
      AND b.year = 2019 AND b.month BETWEEN 3 AND 9
GROUP BY 1, 2, 3, 4, 5