from pygrametl.tables import TypeOneSlowlyChangingDimension

pygram_dim_process_plan_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_process_plan',
    "key": 'process_plan_id',
    "attributes": ['lookup_processplan', 'initial_id', 'company_code', 'period_name', 'count_number', 'period_month',
                   'period_year'],
    "lookupatts": ['lookup_processplan', 'period_name'],
}