from pygrametl.datasources import TransformingSource
from dw_object_folder.parent_class import TransformBase


class DimProcessPlan(TransformBase):
    def run_class_function(self, object_name, data_source):
        # create transforming source
        final_source = TransformingSource(data_source, self.add_month_and_year, self.add_config_name)
        print('done query and transform {}'.format(object_name))
        return final_source