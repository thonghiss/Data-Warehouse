CREATE TABLE IF NOT EXISTS dim_process_plan
(
  process_plan_id SERIAL  NOT NULL
    PRIMARY KEY,
  lookup_processplan VARCHAR,
  initial_id         INTEGER,
  company_code    VARCHAR,
  period_name     VARCHAR,
  period_month    INTEGER,
  period_year     INTEGER,
  count_number    NUMERIC
)