from pygrametl.tables import TypeOneSlowlyChangingDimension

# Partner Dimension
pygram_dim_process_alert_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_process_alert',
    "key": 'process_alert_id',
    "attributes": ['company_code', 'group_of_days', 'group_of_hours', 'min_number', 'max_number'],
    "lookupatts": ['company_code','group_of_days','group_of_hours']
}