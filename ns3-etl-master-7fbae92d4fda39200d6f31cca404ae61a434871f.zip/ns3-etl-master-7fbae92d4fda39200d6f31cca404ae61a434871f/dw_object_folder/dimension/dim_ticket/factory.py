from pygrametl.tables import TypeOneSlowlyChangingDimension

# Ticket Dimension
pygram_dim_ticket_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_ticket',
    "key": 'ticket_id',
    "attributes": ['lookup_ticket',
                   'initial_id',
                   'company_code',
                   'type_name',
                   'stage_name',
                   'department_name',
                   'create_call_ticket',
                   'is_dvc',
                   'partner_id',
                   'partner_address',
                   'expired_to_text',
                   'priority',
                   'kanban_state',
                   'start_date',
                   'finish_date',
                   'handle_date',
                   'handle_time',
                   'description',
                   'results'
                   ],
    "lookupatts": ['lookup_ticket']
}