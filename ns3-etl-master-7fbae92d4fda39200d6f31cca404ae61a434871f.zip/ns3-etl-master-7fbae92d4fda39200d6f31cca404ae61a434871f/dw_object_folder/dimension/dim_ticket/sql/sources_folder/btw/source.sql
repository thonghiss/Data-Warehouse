SELECT
  a.id                                                                AS initial_id,
  b.name                                                              AS type_name,
  c.name                                                              AS stage_name,
  d.name                                                              AS department_name,
  b.create_call_ticket,
  b.is_dvc,
  a.partner_id,
  a.partner_address,
  a.expired_to_text,
  a.priority,
  a.kanban_state,
  a.start_date,
  a.finish_date,
  a.handle_date,
  date_part('epoch', a.finish_date) - date_part('epoch', a.handle_date) AS handle_time,
  a.description,
  a.results
FROM helpdesk_ticket AS a, helpdesk_ticket_type AS b, helpdesk_stage AS c, hr_department AS d
WHERE a.ticket_type_id = b.id
      AND a.stage_id = c.id
      AND a.department_id = d.id
      AND a.start_date >= date_trunc('month', now()) - interval '1 month';