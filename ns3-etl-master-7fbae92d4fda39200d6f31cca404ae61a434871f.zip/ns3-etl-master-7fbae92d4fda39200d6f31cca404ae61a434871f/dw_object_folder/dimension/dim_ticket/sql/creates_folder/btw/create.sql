CREATE TABLE IF NOT EXISTS dim_ticket
(
  ticket_id SERIAL  NOT NULL
    PRIMARY KEY,
  lookup_ticket         VARCHAR,
  initial_id      INTEGER,
  company_code    VARCHAR,
  type_name       VARCHAR,
  stage_name        VARCHAR,
  department_name   VARCHAR,
  create_call_ticket     BOOLEAN,
  is_dvc   BOOLEAN,
  partner_id  INTEGER,
  partner_address VARCHAR,
  expired_to_text VARCHAR,
  priority  INTEGER,
  kanban_state VARCHAR,
  start_date TIMESTAMP,
  finish_date TIMESTAMP,
  handle_date TIMESTAMP ,
  handle_time DOUBLE PRECISION,
  description VARCHAR,
  results     VARCHAR
)