from pygrametl.tables import CachedDimension, TypeOneSlowlyChangingDimension

pygram_dim_invoice_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_invoice',
    "key": 'invoice_id',
    "attributes": ['lookup_invoice', 'initial_id', 'company_code', 'origin', 'type', 'number',
                   'invoice_state', 'transaction_state', 'sent', 'partner_id', 'partner_ref', 'receipt_employee_id',
                   'receipt_employee_login', 'process_employee_id', 'process_employee_login', 'invoice_create_date',
                   'discount',
                   'invoice_payment_date', 'invoice_paid_date', 'amount_total', 'amount_untaxed', 'number_total'],
    "lookupatts": ['lookup_invoice'],
}
