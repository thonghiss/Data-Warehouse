SELECT
  table_1.*,
  table_2.number_total,
  table_2.discount
FROM (
       SELECT
         a.id                    AS initial_id,
         a.origin,
         a.type,
         a.number,
         a.state                 AS invoice_state,
         b.state                 AS transaction_state,
         a.sent,
         a.partner_id,
         c.ref                   AS partner_ref,
         b.receipt_user          AS receipt_employee_id,
         d.login                 AS receipt_employee_login,
         b.process_user_id       AS process_employee_id,
         d_1.login               AS process_employee_login,
         a.date_invoice          AS invoice_create_date,
         b.payment_date          AS invoice_payment_date,
         a.register_payment_date AS invoice_paid_date,
         a.amount_total,
         a.amount_untaxed
       FROM
         (((account_invoice AS a INNER JOIN ccbs_transaction AS b ON a.transaction_id = b.id) INNER JOIN
           res_partner AS c
             ON a.partner_id = c.id) LEFT JOIN res_users AS d ON b.receipt_user = d.id) LEFT JOIN res_users AS d_1
           ON b.process_user_id = d_1.id
       WHERE a.date_invoice >= date_trunc('month', now()) - interval '1 month') AS table_1 INNER JOIN
  (SELECT
     invoice_id,
     discount,
     sum(quantity) AS number_total
   FROM account_invoice_line
   WHERE create_date >= date_trunc('month', now()) - interval '1 month'
   GROUP BY invoice_id, discount) AS table_2 ON table_1.initial_id = table_2.invoice_id;