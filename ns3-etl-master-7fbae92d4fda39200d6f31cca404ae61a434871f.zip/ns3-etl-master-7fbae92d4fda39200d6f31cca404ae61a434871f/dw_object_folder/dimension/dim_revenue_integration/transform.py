import pandas as pd
from pygrametl.datasources import TransformingSource, PandasSource
import numpy as np
from dw_object_folder.parent_class import TransformBase



class DimRevenueIntegration(TransformBase):
    # return the function of two point on graph
    def f(self, x, point_1=[], point_2=[]):
        delta_y = point_2[1] - point_1[1]
        delta_x = point_2[0] - point_1[0]
        if delta_x == 0:
            delta_x = 0.01

        a = delta_y / delta_x
        b = point_1[1] - a * point_1[0]
        y = a * x + b
        return y

    def dimension_integration(self, row):
        if row['next_epoch'] == 0 and row['next_revenue_cumulative'] == 0:
            area = 0
        else:
            row['next_revenue_cumulative'] = int(row['next_revenue_cumulative'])
            row['revenue_cumulative'] = int(row['revenue_cumulative'])
            n = abs(row['epoch'] - row['next_epoch']) + 1
            t = np.linspace(row['epoch'], row['next_epoch'], n)
            fx = self.f(t, point_1=[row['epoch'], (row['revenue_cumulative'] / 1000)],
                        point_2=[row['next_epoch'], (row['next_revenue_cumulative'] / 1000)])
            area = np.sum(fx) * abs((row['epoch'] - row['next_epoch'])) / n
        return area

    def run_class_function(self, object_name, data_source):
        # create transforming source
        transforming_source = TransformingSource(data_source, self.round_time)

        # create dataframe
        df = pd.DataFrame(transforming_source)
        if len(df) == 0:
            print('no record in query period')
        else:
            # pandas transformation
            df = df[df['sent_signal'] == False]
            df = df[df['amount_signal'] > 0]
            df = df.groupby(['period_name','epoch']).agg({'revenue': 'sum'}).reset_index()

            df = df.sort_values(by=['epoch'])
            group_df = df.groupby(['period_name'])
            df['revenue_cumulative'] = group_df['revenue'].apply(lambda x: x.cumsum())
            df = df.assign(next_epoch=group_df['epoch'].shift(-1))
            df = df.assign(next_revenue_cumulative=group_df['revenue_cumulative'].shift(-1))

            df['next_epoch'].fillna(0, inplace=True)
            df['next_revenue_cumulative'].fillna(0, inplace=True)
            df['area_integration'] = df.apply(self.dimension_integration, axis=1)

            df['company_code'] = self.get_company_code()


        # create pandasSource
        final_source = PandasSource(df)
        print('done query and transform {}'.format(object_name))
        return final_source