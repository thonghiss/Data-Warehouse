CREATE TABLE IF NOT EXISTS dim_revenue_integration
(
  revenue_integration_id SERIAL  NOT NULL
    PRIMARY KEY,
  period_name   VARCHAR,
  epoch         INTEGER NOT NULL,
  company_code  VARCHAR NOT NULL,
  revenue       NUMERIC,
  revenue_cumulative  NUMERIC,
  next_epoch    INTEGER,
  next_revenue_cumulative  NUMERIC,
  area_integration   NUMERIC
)
