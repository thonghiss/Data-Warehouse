SELECT
  DISTINCT ON (inv.id)
  inv.id                                                                           AS inv_id,
  extract(MONTH FROM mtv.create_date) || '/' || extract(YEAR FROM mtv.create_date) AS period_name,
  mtv.create_date                                                                  AS date,
  inv.amount_total                                                                 AS revenue,
  inv.sent                                                                         AS sent_signal,
  inv.amount_untaxed_signed                                                        AS amount_signal
FROM mail_message AS mm, mail_tracking_value AS mtv, account_invoice AS inv
WHERE mm.id = mtv.mail_message_id
      AND mm.res_id = inv.id
      AND mm.model = 'account.invoice'
      AND mtv.field = 'state'
      AND mtv.create_date >= date_trunc('month', now()) - INTERVAL '1 month'
      AND mtv.old_value_char = 'Mở'
      AND mtv.new_value_char = 'Đã thanh toán'
ORDER BY inv.id DESC, mtv.create_date DESC