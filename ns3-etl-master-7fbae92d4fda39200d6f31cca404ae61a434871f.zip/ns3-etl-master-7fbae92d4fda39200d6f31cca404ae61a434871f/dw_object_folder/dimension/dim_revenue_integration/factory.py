from pygrametl.tables import TypeOneSlowlyChangingDimension

pygram_dim_revenue_integration_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_revenue_integration',
    "key": 'revenue_integration_id',
    "attributes": ['period_name', 'epoch', 'company_code', 'revenue', 'revenue_cumulative', 'next_epoch',
                   'next_revenue_cumulative',
                   'area_integration'],
    "lookupatts": ['epoch', 'company_code'],
}