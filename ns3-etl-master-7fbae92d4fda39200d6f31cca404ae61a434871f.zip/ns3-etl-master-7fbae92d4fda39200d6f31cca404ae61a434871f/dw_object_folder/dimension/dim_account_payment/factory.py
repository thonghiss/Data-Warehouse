from pygrametl.tables import TypeOneSlowlyChangingDimension

pygram_dim_account_payment_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_account_payment',
    "key": 'account_payment_id',
    "attributes": ['lookup_accountpayment', 'initial_id', 'company_code', 'name', 'state', 'payment_type', 'partner_id',
                   'amount', 'payment_date'],
    "lookupatts": ['lookup_accountpayment']
}
