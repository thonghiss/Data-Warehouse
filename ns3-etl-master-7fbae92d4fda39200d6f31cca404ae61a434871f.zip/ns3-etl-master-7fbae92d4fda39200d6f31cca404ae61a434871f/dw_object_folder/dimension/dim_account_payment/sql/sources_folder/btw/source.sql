SELECT
  id AS initial_id,
  name,
  state,
  payment_type,
  partner_type,
  partner_id,
  amount,
  payment_date
FROM account_payment
WHERE payment_date >= date_trunc('month', now()) - interval '1 month'