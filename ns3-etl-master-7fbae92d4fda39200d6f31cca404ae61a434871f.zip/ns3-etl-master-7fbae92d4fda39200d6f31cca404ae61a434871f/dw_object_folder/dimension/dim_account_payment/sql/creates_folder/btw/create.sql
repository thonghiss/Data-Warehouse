CREATE TABLE IF NOT EXISTS dim_account_payment (
  account_payment_id SERIAL PRIMARY KEY,
  lookup_accountpayment VARCHAR,
  initial_id     INTEGER,
  company_code    VARCHAR,
  name       VARCHAR,
  state        VARCHAR,
  payment_type      VARCHAR,
  partner_id      INTEGER ,
  amount       NUMERIC ,
  payment_date  TIMESTAMP
)