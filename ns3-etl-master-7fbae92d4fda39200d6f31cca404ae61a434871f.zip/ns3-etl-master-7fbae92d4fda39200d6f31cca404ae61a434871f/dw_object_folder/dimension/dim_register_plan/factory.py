from pygrametl.tables import TypeOneSlowlyChangingDimension

pygram_dim_register_plan_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_register_plan',
    "key": 'register_plan_id',
    "attributes": ['lookup_registerplan', 'initial_id', 'company_code', 'period_name', 'count_number', 'period_month',
                   'period_year'],
    "lookupatts": ['lookup_registerplan', 'period_name'],
}