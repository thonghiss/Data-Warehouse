CREATE TABLE IF NOT EXISTS dim_register_plan
(
  register_plan_id SERIAL  NOT NULL
    PRIMARY KEY,
  lookup_registerplan   VARCHAR,
  initial_id         INTEGER,
  company_code    VARCHAR,
  period_name     VARCHAR,
  period_month    INTEGER,
  period_year     INTEGER,
  count_number    NUMERIC
)