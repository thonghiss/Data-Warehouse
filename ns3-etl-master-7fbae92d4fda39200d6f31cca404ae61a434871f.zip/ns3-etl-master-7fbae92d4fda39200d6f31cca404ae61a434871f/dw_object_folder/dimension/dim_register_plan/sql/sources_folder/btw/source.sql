SELECT
  ccbs.register_user_id AS initial_id,
  period.name           AS period_name,
  count(1)              AS count_number
FROM ccbs_transaction AS ccbs, res_users AS ru, ccbs_period AS period
WHERE ccbs.register_user_id = ru.id AND ccbs.period_id = period.id
GROUP BY 1, 2