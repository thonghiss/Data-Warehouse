CREATE TABLE IF NOT EXISTS dim_zero_quantity_partner (
  zero_quantity_partner_id SERIAL PRIMARY KEY,
  period_name VARCHAR,
  company_code  VARCHAR ,
  count_zero_quantity_partner    INTEGER,
  period_month    INTEGER ,
  period_year     INTEGER
)