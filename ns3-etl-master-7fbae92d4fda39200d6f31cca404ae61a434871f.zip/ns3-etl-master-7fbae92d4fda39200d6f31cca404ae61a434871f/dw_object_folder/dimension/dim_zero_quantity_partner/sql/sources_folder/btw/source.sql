SELECT
  b.name                     AS period_name,
  count(DISTINCT partner_id) AS count_zero_quantity_partner
FROM ccbs_transaction AS a, ccbs_period AS b
WHERE a.period_id = b.id
      AND number_total = 0
GROUP BY 1