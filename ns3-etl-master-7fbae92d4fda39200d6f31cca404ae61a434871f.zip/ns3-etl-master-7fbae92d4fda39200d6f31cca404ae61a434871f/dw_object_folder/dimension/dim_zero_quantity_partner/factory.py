from pygrametl.tables import TypeOneSlowlyChangingDimension

pygram_dim_zero_quantity_partner_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_zero_quantity_partner',
    "key": 'zero_quantity_partner_id',
    "attributes": ['period_name', 'company_code', 'count_zero_quantity_partner', 'period_month', 'period_year'],
    "lookupatts": ['period_name', 'company_code'],
}