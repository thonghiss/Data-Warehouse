import pandas as pd
from pygrametl.datasources import TransformingSource, PandasSource
from dw_object_folder.parent_class import TransformBase


class DimZeroQuantityPartner(TransformBase):
    def run_class_function(self, object_name, data_source):
        # create transforming source
        transforming_source = TransformingSource(data_source, self.add_month_and_year)

        #pandas transformation
        df = pd.DataFrame(transforming_source)
        df['company_code'] = self.get_company_code()

        # create pandasSource
        final_source = PandasSource(df)
        print('done query and transform {}'.format(object_name))
        return final_source