from pygrametl.tables import CachedDimension, TypeOneSlowlyChangingDimension, FactTable

pygram_dim_message_factory = {
    "class": TypeOneSlowlyChangingDimension,
    "name": 'dim_message',
    "key": 'message_id',
    "attributes": ['lookup_message', 'initial_id', 'company_code', 'supplier', 'is_send',
                   'mobile_number', 'message', 'send_date', 'message_type',
                   'partner_ref', 'number_total', 'amount_total'],
    "lookupatts": ['lookup_message'],
}