import pandas as pd
from pygrametl.datasources import TransformingSource, PandasSource
from dw_object_folder.parent_class import TransformBase
import re


class DimMessage(TransformBase):
    # function to find the index of a val from a list
    def find_index(self,string_list, text):
        for i in range(len(string_list)):
            if string_list[i] == text:
                return i
        return -1

    # function to extract number total based on regex
    def regex_number_total(self,string_list):
        r_number_total = re.compile(".*m3,$")  #regex to match m3, at end of string
        result = list(filter(r_number_total.match, string_list))
        if result:
            return int(result[0][:-3].replace(',', ''))
        else:
            return -1

    # function to extract amount total based on regex
    def regex_amount_total(self,string_list):
        r_amount_total = re.compile(".*d([,]|[.])")    #regex to match 'd,' or 'd.' in string
        match_result = list(filter(r_amount_total.match, string_list))

        if match_result:
            findall_result = re.findall(r'\d+', match_result[0])         #regex find all number in string
            final_result = ''.join([item for item in findall_result])    #join all number in findall list
            return int(final_result)
        else:
            return -1

    # function to extract customer code based on regex
    def regex_partner_ref(self,string_list):
        index_ma = self.find_index(string_list,'ma:')      #find the index of ma: in whole message
        if index_ma == -1:
            r_partner_ref = re.compile("^ma:.*")      #regex to find string start with ma:
            result = list(filter(r_partner_ref.match, string_list))
            if result:
                return result[0][3:]
            else:
                return -1
        else:
            result = string_list[index_ma+1]
            return result

    # Function to get information from message string
    def get_information(self,row):
        splited_message = row['message'].split()
        if row['message_type'] in ['thong bao','nhac no'] :

            row['number_total'] = self.regex_number_total(splited_message)
            row['amount_total'] = self.regex_amount_total(splited_message)
            row['partner_ref'] = self.regex_partner_ref(splited_message)

        else:
            row['partner_ref'] = None
            row['number_total'] = -1
            row['amount_total'] = -1

    def run_class_function(self, object_name, data_source):
        # create transforming source
        transforming_source = TransformingSource(data_source, self.add_config_name, self.get_information)

        # create dataframe
        df = pd.DataFrame(transforming_source)
        if len(df) == 0:
            print('no record in query period')
        else:
            # pandas transformation
            if self.get_company_code() == 'dtwcns':
                df['company_code'] = 'ns3'
            elif self.run_class_function() == 'btwcns':
                df['company_code'] = 'btw'

        # create pandasSource
        final_source = PandasSource(df)
        # final_source = TransformingSource(pandas_source,self.add_month_and_year)
        print('done query and transform {}'.format(object_name))
        return final_source
