CREATE TABLE IF NOT EXISTS dim_message (
  message_id SERIAL PRIMARY KEY,
  lookup_message VARCHAR,
  initial_id     INTEGER,
  company_code    VARCHAR,
  supplier       VARCHAR,
  is_send        BOOLEAN,
  mobile_number      VARCHAR,
  message      VARCHAR,
  send_date       TIMESTAMP,
  message_type      VARCHAR,
  partner_ref     VARCHAR ,
  number_total    NUMERIC,
  amount_total    NUMERIC
)