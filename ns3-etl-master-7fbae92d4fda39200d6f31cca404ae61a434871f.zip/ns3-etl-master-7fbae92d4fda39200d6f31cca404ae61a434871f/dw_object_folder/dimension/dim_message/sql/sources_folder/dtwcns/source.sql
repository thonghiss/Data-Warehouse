SELECT
   id  AS initial_id,
   supplier,
   is_send,
   mobile_number,
   message,
   send_date,
   CASE
   WHEN message LIKE '%Vui long t/toan%'
     THEN 'nhac no'
   WHEN message LIKE '%Vui long T/toan%'
     THEN 'nhac no'
   WHEN message LIKE '%Huong dan thanh toan%'
     THEN 'thong bao'
   ELSE 'else'
   END AS message_type
 FROM sms_message
 WHERE send_date >= date_trunc('month', now()) - interval '1 month'