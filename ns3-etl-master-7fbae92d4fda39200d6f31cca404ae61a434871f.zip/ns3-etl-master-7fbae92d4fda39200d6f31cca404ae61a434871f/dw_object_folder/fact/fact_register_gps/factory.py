from pygrametl.tables import FactTable

pygram_fact_register_gps_factory = {
    "class": FactTable,
    "name": 'fact_register_gps',
    "keyrefs": ['employee_id', 'datetime_id', 'company_id'],
    "measures": ['count_number', 'mean_lat', 'mean_long', 'max_radius_distance', 'total_distance'],
}