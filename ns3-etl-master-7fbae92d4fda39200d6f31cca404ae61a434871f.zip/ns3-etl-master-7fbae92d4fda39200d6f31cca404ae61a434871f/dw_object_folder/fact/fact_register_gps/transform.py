from math import sin, cos, sqrt, atan2, radians
import pandas as pd
from pygrametl.datasources import TransformingSource, PandasSource
from dw_object_folder.parent_class import TransformBase


class FactRegisterGps(TransformBase):
    # add config name after lookup attribute
    def add_config_fact(self, row):
        src_company_code = self.get_company_code()
        row['lookup_employee'] = str(row['lookup_employee']) + '_' + src_company_code

    # def to get distance from mean
    def get_distance_from_mean(self, row):
        # estimated Earth radius
        R = 6376
        # convert degree to radian
        lat1 = radians(row['mean_lat'])
        long1 = radians(row['mean_long'])
        lat2 = radians(row['lat'])
        long2 = radians(row['long'])
        # difference
        delta_long = long2 - long1
        delta_lat = lat2 - lat1
        # temp value (based on haversin)
        a = sin(delta_lat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(delta_long / 2) ** 2
        b = 2 * atan2(sqrt(a), sqrt(1 - a))
        # distance
        distance = R * b
        return distance

    # def to get_distance_from_last
    def get_distance_from_last(self, row):
        # estimated Earth radius
        R = 6376
        # convert degree to radian
        if row['next_lat'] and row['next_long']:
            lat1 = radians(row['next_lat'])
            long1 = radians(row['next_long'])
            lat2 = radians(row['lat'])
            long2 = radians(row['long'])
            # difference
            delta_long = long2 - long1
            delta_lat = lat2 - lat1
            # temp value (based on haversin)
            a = sin(delta_lat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(delta_long / 2) ** 2
            b = 2 * atan2(sqrt(a), sqrt(1 - a))
            # distance
            distance = R * b
        else:
            distance = 0
        return distance

    def run_class_function(self, object_name, data_source):
        # create transforming source
        transforming_source = TransformingSource(data_source, self.round_time, self.add_config_fact)

        # check if recond == 0
        df = pd.DataFrame(transforming_source)
        if len(df) == 0:
            print('no record in query period')
        else:
            # pandas transformation
            group_df = df.groupby(['lookup_employee', 'epoch'])
            df['count_number'] = group_df['id'].transform('count')
            df['mean_lat'] = group_df['lat'].transform('mean')
            df['mean_long'] = group_df['long'].transform('mean')
            df['distance_from_mean'] = df.apply(self.get_distance_from_mean, axis=1)
            df = df.sort_values(by=['epoch'])
            df = df.assign(next_lat=group_df['lat'].shift(-1))
            df = df.assign(next_long=group_df['long'].shift(-1))
            df['distance_from_last'] = df.apply(self.get_distance_from_last, axis=1)
            df = df.groupby(['lookup_employee', 'epoch', 'count_number', 'mean_lat', 'mean_long']).agg(
                {'distance_from_mean': 'max', 'distance_from_last': 'sum'}).reset_index()
            df.rename({'distance_from_mean': 'max_radius_distance', 'distance_from_last': 'total_distance'}, axis=1,
                      inplace=True)
            df['company_code'] = self.get_company_code()
            df = df[df['epoch'] < df['epoch'].max()]

        # create pandasSource
        final_source = PandasSource(df)
        print('done query and transform {}'.format(object_name))
        return final_source