CREATE TABLE IF NOT EXISTS fact_register_gps
(
  employee_id  INTEGER NOT NULL,
  datetime_id  INTEGER NOT NULL,
  company_id   INTEGER NOT NULL,
  count_number NUMERIC,
  mean_lat     NUMERIC,
  mean_long    NUMERIC,
  max_radius_distance   NUMERIC,
  total_distance        NUMERIC,
  PRIMARY KEY (employee_id, datetime_id, company_id)
)