SELECT
  DISTINCT ON (trans.id)
  trans.id,
  trans.register_user_id AS lookup_employee,
  trans.result_date AS date,
  gps.lat,
  gps.long
FROM ccbs_transaction AS trans, ccbs_transaction_gps AS gps
WHERE
  trans.id = gps.transaction_id AND gps.gps_action = 'confirm_ghi' AND trans.result_date >= now() - INTERVAL '5 day'
ORDER BY trans.id ASC, trans.result_date ASC