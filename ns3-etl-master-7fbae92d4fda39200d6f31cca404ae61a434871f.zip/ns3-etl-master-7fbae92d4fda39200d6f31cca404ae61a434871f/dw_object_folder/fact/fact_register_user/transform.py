import pandas as pd
from pygrametl.datasources import TransformingSource, PandasSource
from dw_object_folder.parent_class import TransformBase


class FactRegisterUser(TransformBase):
    # add config name after lookup attribute
    def add_config_fact(self, row):
        src_company_code = self.get_company_code()
        row['lookup_employee'] = str(row['lookup_employee']) + '_' + src_company_code
        row['lookup_location'] = str(row['lookup_location']) + '_' + src_company_code

    def run_class_function(self, object_name, data_source):
        # create transforming source
        transforming_source = TransformingSource(data_source, self.round_time, self.add_config_fact)

        # using pandas to aggregate on multiple columns
        df = pd.DataFrame(transforming_source)
        if len(df) == 0:
            print('no record in query period')
        else:
            df = df.groupby(['lookup_employee', 'epoch', 'lookup_location']).agg({'id': 'count'}).reset_index()
            df.rename({'id': 'count_number'}, axis=1, inplace=True)
            df['company_code'] = self.get_company_code()
            df = df[df['epoch'] < df['epoch'].max()]

        # create pandasSource
        final_source = PandasSource(df)
        print('done query and transform {}'.format(object_name))
        return final_source