SELECT
  a.id,
  c.street_id AS lookup_location,
  a.register_user_id AS lookup_employee,
  a.result_date      AS date
FROM ccbs_transaction AS a, res_partner AS c
WHERE a.partner_id = c.id
      AND a.result_date IS NOT NULL
      AND a.register_user_id IS NOT NULL
      AND c.street_id IS NOT NULL
      AND a.result_date >= now() - INTERVAL '5 day'