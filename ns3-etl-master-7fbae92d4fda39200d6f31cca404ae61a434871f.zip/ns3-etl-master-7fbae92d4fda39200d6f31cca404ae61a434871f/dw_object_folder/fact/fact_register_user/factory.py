from pygrametl.tables import FactTable

pygram_fact_register_user_factory = {
    "class": FactTable,
    "name": 'fact_register_user',
    "keyrefs": ['employee_id', 'location_id', 'datetime_id', 'company_id'],
    "measures": ['count_number'],
}