from pygrametl.tables import FactTable

pygram_fact_revenue_quantity_min10_factory = {
    "class": FactTable,
    "name": 'fact_revenue_quantity_min10',
    "keyrefs": ['employee_id', 'partner_id', 'datetime_id', 'company_id'],
    "measures": ['revenue', 'quantity'],
}