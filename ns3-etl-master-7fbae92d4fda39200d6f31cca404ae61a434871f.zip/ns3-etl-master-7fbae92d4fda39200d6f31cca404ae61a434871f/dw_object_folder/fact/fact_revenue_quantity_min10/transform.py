import pandas as pd
from pygrametl.datasources import TransformingSource, PandasSource
from dw_object_folder.parent_class import TransformBase


class FactRevenueQuantityMin10(TransformBase):
    def add_config_fact(self, row):
        if row['lookup_employee'] is None:
            row['lookup_employee'] = 100000
        src_company_code = self.get_company_code()
        row['lookup_employee'] = str(row['lookup_employee']) + '_' + src_company_code
        row['lookup_partner'] = str(row['lookup_partner']) + '_' + src_company_code

    def run_class_function(self, object_name, data_source):
        # create transforming source
        transforming_source = TransformingSource(data_source, self.add_config_fact, self.round_time)

        # create dataframe
        df = pd.DataFrame(transforming_source)
        if len(df) == 0:
            print('no record in query period')
        else:
            # pandas transformation
            df = df[df['sent_signal'] == False]
            df = df[df['amount_signal'] > 0]

            df = df.groupby(['lookup_employee', 'lookup_partner', 'epoch']).agg(
                {'revenue': 'sum', 'quantity': 'sum'}).reset_index()

            df['company_code'] = self.get_company_code()
            df = df[df['epoch'] < df['epoch'].max()]
        # create pandas source
        final_source = PandasSource(df)
        print('done query and transform {}'.format(object_name))
        return final_source