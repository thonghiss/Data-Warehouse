 CREATE TABLE IF NOT EXISTS fact_revenue_quantity_min10
(
  employee_id  INTEGER NOT NULL,
  partner_id   INTEGER NOT NULL,
  datetime_id  INTEGER NOT NULL,
  company_id   INTEGER NOT NULL,
  revenue      NUMERIC,
  quantity     NUMERIC,
  PRIMARY KEY (employee_id, partner_id, datetime_id, company_id)
)