SELECT
  DISTINCT ON (inv.id)
  inv.id                    AS inv_id,
  trans.receipt_user        AS lookup_employee,
  inv.partner_id            AS lookup_partner,
  mtv.create_date           AS date,
  inv.amount_total          AS revenue,
  inv.number_total          AS quantity,
  inv.sent                  AS sent_signal,
  inv.amount_untaxed_signed AS amount_signal

FROM mail_message AS mm, mail_tracking_value AS mtv, account_invoice AS inv, ccbs_transaction AS trans
WHERE mm.id = mtv.mail_message_id
      AND mm.res_id = inv.id
      AND inv.transaction_id = trans.id
      AND mm.model = 'account.invoice'
      AND mtv.field = 'state'
      AND mtv.create_date >= now() - INTERVAL '5 day'
      AND mtv.old_value_char = 'Mở'
      AND inv.partner_id IS NOT NULL
      AND mtv.new_value_char = 'Đã thanh toán'
ORDER BY inv.id DESC, mtv.create_date DESC