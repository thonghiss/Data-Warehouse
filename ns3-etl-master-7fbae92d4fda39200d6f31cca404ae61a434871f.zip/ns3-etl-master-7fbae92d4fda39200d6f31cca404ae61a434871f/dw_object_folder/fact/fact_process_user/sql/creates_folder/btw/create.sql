CREATE TABLE IF NOT EXISTS fact_process_user
(
  employee_id  INTEGER NOT NULL,
  datetime_id  INTEGER NOT NULL,
  location_id  INTEGER NOT NULL,
  company_id  INTEGER NOT NULL,
  count_number NUMERIC,
  PRIMARY KEY (employee_id, location_id, datetime_id, company_id)
)