SELECT
  DISTINCT ON (a.id)
  a.id,
  c.street_id       AS lookup_location,
  a.process_user_id AS lookup_employee,
  hist.create_date  AS date
FROM ccbs_transaction AS a, res_partner AS c, ccbs_history AS hist
WHERE a.partner_id = c.id
      AND hist.transaction_id = a.id
      AND hist.field = 'state'
      AND hist.old_value_char = 'Chưa thu'
      AND hist.new_value_char = 'Đã thu'
      AND c.street_id IS NOT NULL
      AND a.process_user_id IS NOT NULL
      AND hist.create_date >= now() - INTERVAL '5 day'
ORDER BY a.id, hist.create_date DESC;