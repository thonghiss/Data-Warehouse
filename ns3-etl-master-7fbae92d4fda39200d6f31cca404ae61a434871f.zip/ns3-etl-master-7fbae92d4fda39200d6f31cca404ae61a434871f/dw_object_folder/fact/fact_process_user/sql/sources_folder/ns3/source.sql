SELECT
  DISTINCT ON (a.id)
  a.id,
  c.street_id AS lookup_location,
  a.process_user_id AS lookup_employee,
  mtv.create_date AS date
FROM ccbs_transaction AS a, res_partner AS c, mail_message AS mm, mail_tracking_value AS mtv
WHERE a.partner_id = c.id
      AND a.id = mm.res_id
      AND mm.id = mtv.mail_message_id
      AND mm.model = 'ccbs.transaction'
      AND mtv.field = 'state'
      AND mtv.old_value_char = 'Chưa thu'
      AND mtv.new_value_char = 'Đã thu'
      AND c.street_id IS NOT NULL
      AND a.process_user_id IS NOT NULL
      AND mtv.create_date >= now() - INTERVAL '5 day'
ORDER BY a.id, date DESC